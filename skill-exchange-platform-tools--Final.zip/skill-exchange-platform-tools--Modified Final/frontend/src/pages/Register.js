import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    skillsOffered: "",
    skillsWanted: "",
    resume: null,
    certification: null,
  });
  const [error, setError] = useState("");
  const [focusedInput, setFocusedInput] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setForm({ ...form, [name]: files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setError("");

      const formData = new FormData();
      formData.append("name", form.name);
      formData.append("email", form.email);
      formData.append("password", form.password);
      formData.append("skillsOffered", form.skillsOffered);
      formData.append("skillsWanted", form.skillsWanted);
      if (form.resume) formData.append("resume", form.resume);
      if (form.certification)
        formData.append("certification", form.certification);

      await axios.post("http://localhost:5000/api/auth/register", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      alert("✅ Registration successful! Please login.");
      navigate("/login");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    }
  };

  // --- Styling ---
  const containerStyle = {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundImage:
      "url('https://media.istockphoto.com/id/1493013286/photo/businessman-logging-on-to-a-password-protected-website.jpg?s=612x612&w=0&k=20&c=T8d5OU59JrtFQQmdx0ANwlLdV7Of0B9QyN-ZfY79CUY=')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    padding: 20,
  };

  const formStyle = {
    background: "rgba(255, 255, 255, 0.25)",
    backdropFilter: "blur(10px)",
    padding: "40px 30px",
    borderRadius: "12px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.25)",
    width: "100%",
    maxWidth: "400px",
    boxSizing: "border-box",
    textAlign: "center",
    color: "#000",
  };

  const inputStyle = {
    width: "100%",
    padding: "12px 15px",
    margin: "10px 0",
    borderRadius: "8px",
    border: "1.5px solid #ccc",
    fontSize: "16px",
    boxSizing: "border-box",
    outline: "none",
    transition: "border-color 0.3s ease",
  };

  const inputFocusStyle = {
    borderColor: "#000",
    boxShadow: "0 0 8px #000",
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px 0",
    background: "#000", // black button
    border: "none",
    borderRadius: "10px",
    color: "white",
    fontWeight: "600",
    fontSize: "18px",
    cursor: "pointer",
    marginTop: "15px",
    transition: "background 0.3s ease, transform 0.2s ease",
  };

  const buttonHoverStyle = {
    background: "#333",
    transform: "scale(1.02)",
  };

  const errorStyle = {
    color: "#e74c3c",
    marginTop: "15px",
    fontWeight: "600",
  };

  return (
    <div style={containerStyle}>
      <form onSubmit={handleSubmit} style={formStyle} noValidate autoComplete="off">
        <h2 style={{ marginBottom: 20, color: "#000" }}>Register</h2>

        <input
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          onFocus={() => setFocusedInput("name")}
          onBlur={() => setFocusedInput(null)}
          required
          style={{
            ...inputStyle,
            ...(focusedInput === "name" ? inputFocusStyle : {}),
          }}
        />

        <input
          name="email"
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          onFocus={() => setFocusedInput("email")}
          onBlur={() => setFocusedInput(null)}
          required
          style={{
            ...inputStyle,
            ...(focusedInput === "email" ? inputFocusStyle : {}),
          }}
        />

        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          onFocus={() => setFocusedInput("password")}
          onBlur={() => setFocusedInput(null)}
          required
          style={{
            ...inputStyle,
            ...(focusedInput === "password" ? inputFocusStyle : {}),
          }}
        />

        <input
          name="skillsOffered"
          placeholder="Skills Offered (comma separated)"
          value={form.skillsOffered}
          onChange={handleChange}
          onFocus={() => setFocusedInput("skillsOffered")}
          onBlur={() => setFocusedInput(null)}
          style={{
            ...inputStyle,
            ...(focusedInput === "skillsOffered" ? inputFocusStyle : {}),
          }}
        />

        <input
          name="skillsWanted"
          placeholder="Skills Wanted (comma separated)"
          value={form.skillsWanted}
          onChange={handleChange}
          onFocus={() => setFocusedInput("skillsWanted")}
          onBlur={() => setFocusedInput(null)}
          style={{
            ...inputStyle,
            ...(focusedInput === "skillsWanted" ? inputFocusStyle : {}),
          }}
        />

        {/* Resume Upload */}
        <label
          style={{
            fontWeight: "600",
            color: "#000",
            display: "block",
            marginTop: "10px",
          }}
        >
          Upload Resume (PDF)
        </label>
        <input
          type="file"
          name="resume"
          accept="application/pdf"
          onChange={handleFileChange}
          required
          style={inputStyle}
        />

        {/* Certification Upload */}
        <label
          style={{
            fontWeight: "600",
            color: "#000",
            display: "block",
            marginTop: "10px",
          }}
        >
          Upload Certification (PDF)
        </label>
        <input
          type="file"
          name="certification"
          accept="application/pdf"
          onChange={handleFileChange}
          required
          style={inputStyle}
        />

        <button
          type="submit"
          style={buttonStyle}
          onMouseEnter={(e) => Object.assign(e.currentTarget.style, buttonHoverStyle)}
          onMouseLeave={(e) => Object.assign(e.currentTarget.style, buttonStyle)}
        >
          Register
        </button>

        {error && <p style={errorStyle}>{error}</p>}
      </form>
    </div>
  );
}
