// src/pages/Chat.js
import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { io } from "socket.io-client";

export default function Chat({ otherUserId, token, currentUser }) {
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  const socketRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (!token || !currentUser) return;

    // connect socket
    socketRef.current = io("http://localhost:5000", {
      auth: { token }, // optional if you want to use socket auth later
    });

    // join as room named by userId (server emits to rooms by userId)
    socketRef.current.emit("join", currentUser.id || currentUser._id);

    // receive real-time messages
    socketRef.current.on("receiveMessage", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    return () => {
      socketRef.current.disconnect();
    };
  }, [token, currentUser]);

  // load history
  useEffect(() => {
    if (!otherUserId || !token) return;
    axios
      .get(`/api/chat/${otherUserId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setMessages(res.data || []))
      .catch((err) => console.error(err));
  }, [otherUserId, token]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!message.trim()) return;
    // send over socket; server will persist and emit to both sides
    socketRef.current.emit("sendMessage", {
      otherUserId,
      message,
    });

    // optimistic UI: will also receive via receiveMessage echo, but keep this so local shows instantly
    const localMsg = {
      sender: { _id: currentUser.id || currentUser._id, name: currentUser.name },
      message,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, localMsg]);
    setMessage("");
  };

  return (
    <div style={{ padding: "10px", width: 320 }}>
      <div style={{ height: "300px", overflowY: "auto", border: "1px solid #ccc", padding: "10px", background: "white" }}>
        {messages.map((m, i) => (
          <p key={i} style={{ margin: "6px 0" }}>
            <b>{m.sender?.name || (m.sender?._id === (currentUser.id || currentUser._id) ? "You" : "Them")}:</b>{" "}
            {m.message}
          </p>
        ))}
        <div ref={bottomRef} />
      </div>
      <div style={{ marginTop: "8px", display: "flex", gap: "8px" }}>
        <input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Type a message..."
          style={{ flex: 1, padding: "6px" }}
        />
        <button onClick={sendMessage} style={{ padding: "6px 10px" }}>
          Send
        </button>
      </div>
    </div>
  );
}
