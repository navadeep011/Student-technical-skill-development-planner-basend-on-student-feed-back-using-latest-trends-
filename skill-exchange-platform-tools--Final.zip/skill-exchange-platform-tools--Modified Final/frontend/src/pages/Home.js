import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

export default function Home() {
  const [hoveredButton, setHoveredButton] = useState(null);
  const [fadeIn, setFadeIn] = useState(false);

  useEffect(() => {
    setTimeout(() => setFadeIn(true), 100);
  }, []);

  const containerStyle = {
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "center",
    gap: "80px", // space between two cards
    paddingTop: "40px",
    fontFamily: "'Poppins', sans-serif",
    backgroundImage:
      "url('https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTAzfHxlZHVjYXRpb258ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&q=60&w=600')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  };

  const glassStyle = {
    background: "rgba(255, 255, 255, 0.25)",
    backdropFilter: "blur(15px)",
    border: "1px solid rgba(255, 255, 255, 0.3)",
    boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
    borderRadius: "20px",
    color: "#000", // ✅ all text inside cards will be black
    textAlign: "center",
    opacity: fadeIn ? 1 : 0,
    transform: fadeIn ? "scale(1)" : "scale(0.9)",
    transition: "opacity 0.8s ease, transform 0.8s ease",
  };

  // 🔹 Top Card (Heading + Quote)
  const topCardStyle = {
    ...glassStyle,
    width: "55%",
    height: "18vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
  };

  const headingStyle = {
    fontSize: "2rem",
    fontWeight: "800",
    letterSpacing: "1px",
    color: "#000", // ✅ black heading
    textShadow: "0 0 6px rgba(255, 255, 255, 0.5)", // light shadow for clarity
    marginBottom: "6px",
  };

  const quoteStyle = {
    fontStyle: "italic",
    fontSize: "1.1rem",
    color: "#111", // ✅ darker grayish black for quote
    textShadow: "0 0 4px rgba(255, 255, 255, 0.4)",
  };

  // 🔹 Bottom Card (Login/Register)
  const bottomCardStyle = {
    ...glassStyle,
    width: "260px",
    height: "160px",
    padding: "20px 18px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
  };

  const buttonStyle = {
    width: "80%",
    padding: "10px 0",
    background: "linear-gradient(45deg, #2980b9, #6dd5fa)",
    color: "#fff",
    border: "none",
    borderRadius: "50px",
    fontWeight: "700",
    fontSize: "16px",
    cursor: "pointer",
    textDecoration: "none",
    textAlign: "center",
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
    boxShadow: "0 4px 12px rgba(41, 128, 185, 0.4)",
  };

  const buttonHover = {
    transform: "scale(1.1)",
    boxShadow: "0 0 16px rgba(109, 213, 250, 0.8)",
  };

  const footerText = {
    marginTop: "5px",
    fontSize: "0.9rem",
    color: "#000", // ✅ footer text black
    fontWeight: "600",
    textShadow: "0 0 4px rgba(255, 255, 255, 0.3)",
  };

  return (
    <div style={containerStyle}>
      {/* 🔹 Top Card */}
      <div style={topCardStyle}>
        <h1 style={headingStyle}>Welcome to Skill Exchange Platform</h1>
        <p style={quoteStyle}>"Learn what you don't, Teach what you know"</p>
      </div>

      {/* 🔹 Bottom Card */}
      <div style={bottomCardStyle}>
        <Link
          to="/login"
          style={{
            ...buttonStyle,
            ...(hoveredButton === "login" ? buttonHover : {}),
          }}
          onMouseEnter={() => setHoveredButton("login")}
          onMouseLeave={() => setHoveredButton(null)}
        >
          Login
        </Link>

        <Link
          to="/register"
          style={{
            ...buttonStyle,
            ...(hoveredButton === "register" ? buttonHover : {}),
          }}
          onMouseEnter={() => setHoveredButton("register")}
          onMouseLeave={() => setHoveredButton(null)}
        >
          Register
        </Link>

        <p style={footerText}>Join us and share your skills!</p>
      </div>
    </div>
  );
}
