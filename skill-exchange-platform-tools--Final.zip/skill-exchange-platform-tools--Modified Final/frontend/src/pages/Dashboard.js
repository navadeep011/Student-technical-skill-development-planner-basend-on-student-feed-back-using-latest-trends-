import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { io } from "socket.io-client";

const Dashboard = () => {
  const [userMatches, setUserMatches] = useState([]);
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const [logoutHovered, setLogoutHovered] = useState(false);
  const [ratingData, setRatingData] = useState({});
  const [selectedChatUser, setSelectedChatUser] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [unreadMessages, setUnreadMessages] = useState({});
  const [typingUsers, setTypingUsers] = useState({});
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalMatches, setTotalMatches] = useState(0);
  const [username, setUsername] = useState("");

  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const currentUserId = localStorage.getItem("userId");
  const chatEndRef = useRef(null);
  const socket = useRef(null);

  // 🔗 Socket Connection
  useEffect(() => {
    socket.current = io("http://localhost:5000", { transports: ["websocket"] });
    return () => socket.current.disconnect();
  }, []);

  // 🧠 Fetch Matches + Stats
  useEffect(() => {
    if (!token) {
      navigate("/login");
      return;
    }

    const fetchMatches = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/match", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUserMatches(res.data);
        setTotalMatches(res.data.length);
      } catch (err) {
        console.error(err);
        if (err.response?.status === 401) {
          localStorage.removeItem("token");
          navigate("/login");
        }
      }
    };

    const fetchTotalUsers = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/users/count", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setTotalUsers(res.data.totalUsers);
      } catch (err) {
        console.error("Error fetching total users:", err);
      }
    };

    fetchMatches();
    fetchTotalUsers();

    if (currentUserId) socket.current.emit("join", currentUserId);

    socket.current.on("receiveMessage", (msg) => {
      if (selectedChatUser && msg.senderId === selectedChatUser._id) {
        setChatMessages((prev) => [...prev, msg]);
      } else {
        setUnreadMessages((prev) => ({
          ...prev,
          [msg.senderId]: (prev[msg.senderId] || 0) + 1,
        }));
      }
    });

    socket.current.on("typing", ({ senderId, isTyping }) => {
      setTypingUsers((prev) => ({ ...prev, [senderId]: isTyping }));
    });
  }, [token, navigate, currentUserId, selectedChatUser]);

  // 📜 Auto Scroll Chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  // 🧑‍💼 Fetch Current User
  useEffect(() => {
    if (!token) {
      navigate("/login");
      return;
    }

    const fetchCurrentUser = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/users/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUsername(res.data.name);
      } catch (err) {
        console.error("Error fetching user info:", err);
      }
    };

    fetchCurrentUser();
  }, [token, navigate]);

  // 🚪 Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("username");
    navigate("/");
  };

  // ⭐ Rating Submission
  const submitRating = async (ratedUserId) => {
    const { rating, comment } = ratingData[ratedUserId] || {};
    if (!rating) return alert("Please select a rating");

    try {
      await axios.post(
        "http://localhost:5000/api/rating/submit",
        { ratedUserId, rating, comment },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setUserMatches((prev) =>
        prev.map((u) =>
          u._id === ratedUserId
            ? { ...u, rating: u.rating ? (u.rating + rating) / 2 : rating }
            : u
        )
      );

      alert("✅ Feedback submitted!");
    } catch (err) {
      console.error(err);
      alert("Error submitting feedback");
    }
  };

  // 💬 Chat
  const openChat = async (user) => {
    setSelectedChatUser(user);
    setUnreadMessages((prev) => ({ ...prev, [user._id]: 0 }));

    try {
      const res = await axios.get(`http://localhost:5000/api/chat/${user._id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setChatMessages(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const sendMessage = () => {
    if (!newMessage.trim() || !selectedChatUser) return;

    const msgData = {
      senderId: currentUserId,
      receiverId: selectedChatUser._id,
      message: newMessage,
    };

    axios.post(
      `http://localhost:5000/api/chat/${selectedChatUser._id}`,
      { message: newMessage },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    socket.current.emit("sendMessage", msgData);
    socket.current.emit("typing", { senderId: currentUserId, isTyping: false });

    setChatMessages((prev) => [
      ...prev,
      { senderId: currentUserId, sender: { _id: currentUserId, name: "You" }, message: newMessage },
    ]);

    setNewMessage("");
  };

  const handleTyping = (e) => {
    setNewMessage(e.target.value);
    socket.current.emit("typing", { senderId: currentUserId, isTyping: e.target.value.length > 0 });
  };

  // 🎨 Styles
  const containerStyle = {
    minHeight: "100vh",
    backgroundImage:
      "url('https://media.istockphoto.com/id/482073694/photo/time-for-a-quick-brainstorm.jpg?s=612x612&w=0&k=20&c=Zltbl9b1qQXrmGeYO4JllFolhHhLTqVt6VVfJx_DqtA=')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    padding: "40px 20px",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    color: "#000",
  };

  const glassSectionStyle = {
    background: "rgba(255, 255, 255, 0.2)",
    backdropFilter: "blur(10px)",
    WebkitBackdropFilter: "blur(10px)",
    borderRadius: "20px",
    border: "1px solid rgba(255, 255, 255, 0.3)",
    boxShadow: "0 8px 25px rgba(0,0,0,0.15)",
    padding: "30px 50px",
    marginBottom: "40px",
    textAlign: "center",
  };

  const badgeStyle = {
    display: "inline-block",
    color: "white",
    padding: "15px 30px",
    borderRadius: "25px",
    fontSize: "1.5rem",
    fontWeight: "700",
    margin: "8px",
    boxShadow: "0 3px 6px rgba(0,0,0,0.15)",
  };

  const matchesContainerStyle = {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "20px",
    width: "100%",
  };

  const cardStyle = {
    backgroundColor: "rgba(255, 255, 255, 0.85)",
    backdropFilter: "blur(8px)",
    borderRadius: "15px",
    boxShadow: "0 8px 20px rgba(0,0,0,0.1)",
    width: "250px",
    padding: "20px",
    transition: "transform 0.2s, box-shadow 0.2s",
  };

  const cardHoverStyle = {
    transform: "translateY(-5px)",
    boxShadow: "0 12px 25px rgba(0,0,0,0.15)",
  };

  const viewButtonStyle = {
    flex: 1,
    backgroundColor: "#6c63ff",
    color: "white",
    padding: "8px",
    borderRadius: "8px",
    border: "none",
    cursor: "pointer",
  };

  return (
    <div style={containerStyle}>
      {/* 🌟 Glass Effect Section */}
      <div style={glassSectionStyle}>
        <h1 style={{ fontSize: "2.5rem", color: "#000", marginBottom: "10px" }}>
          Welcome, {username} 👋
        </h1>

        <div style={{ ...badgeStyle, background: "linear-gradient(90deg, #4a90e2, #007bff)" }}>
          👥 Total Users: {totalUsers}
        </div>

        <div style={{ ...badgeStyle, background: "linear-gradient(90deg, #ff7f50, #ff6347)" }}>
          🔗 Total Matches: {totalMatches}
        </div>

        <h2 style={{ fontSize: "2rem", marginTop: "25px", color: "#000" }}>Your Matches</h2>
      </div>

      {/* 💼 User Cards */}
      <div style={matchesContainerStyle}>
        {userMatches.length === 0 && <p>No matches found yet.</p>}

        {userMatches.map((match, idx) => (
          <div
            key={match._id}
            style={{ ...cardStyle, ...(hoveredIndex === idx ? cardHoverStyle : {}) }}
            onMouseEnter={() => setHoveredIndex(idx)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <strong style={{ fontSize: "1.1rem" }}>{match.name}</strong>
            <p style={{ fontSize: "0.9rem" }}>
              <strong>Offered:</strong> {match.skillsOffered.join(", ")} <br />
              <strong>Wanted:</strong> {match.skillsWanted.join(", ")}
            </p>

            <p>⭐ Avg Rating: {match.rating ? match.rating.toFixed(1) : "No ratings"}</p>

            {/* Rating Section */}
            <label style={{ fontWeight: "600", display: "block", marginTop: "8px" }}>Rate:</label>
            <select
              value={ratingData[match._id]?.rating || ""}
              onChange={(e) =>
                setRatingData((prev) => ({
                  ...prev,
                  [match._id]: {
                    ...(prev[match._id] || {}),
                    rating: Number(e.target.value),
                  },
                }))
              }
              style={{ width: "100%", marginTop: "5px" }}
            >
              <option value="">Select</option>
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>

            <label style={{ fontWeight: "600", display: "block", marginTop: "8px" }}>Feedback:</label>
            <textarea
              placeholder="Write your feedback"
              value={ratingData[match._id]?.comment || ""}
              onChange={(e) =>
                setRatingData((prev) => ({
                  ...prev,
                  [match._id]: {
                    ...(prev[match._id] || {}),
                    comment: e.target.value,
                  },
                }))
              }
              style={{ width: "100%", marginTop: "5px" }}
            ></textarea>

            {/* Resume & Certificate */}
            <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
              {match.resume && (
                <button
                  style={viewButtonStyle}
                  onClick={() =>
                    window.open(`http://localhost:5000/${match.resume}`, "_blank")
                  }
                >
                  📄 View Resume
                </button>
              )}
              {match.certification && (
                <button
                  style={viewButtonStyle}
                  onClick={() =>
                    window.open(`http://localhost:5000/${match.certification}`, "_blank")
                  }
                >
                  🎓 View Certificate
                </button>
              )}
            </div>

            {/* Feedback & Chat */}
            <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
              <button
                onClick={() => submitRating(match._id)}
                style={{
                  flex: 1,
                  backgroundColor: "#4a90e2",
                  color: "white",
                  padding: "8px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Submit Feedback
              </button>
              <button
                onClick={() => openChat(match)}
                style={{
                  flex: 1,
                  backgroundColor: "#2ecc71",
                  color: "white",
                  padding: "8px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                💬 Chat
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 💬 Chat Panel */}
      {selectedChatUser && (
        <div
          style={{
            position: "fixed",
            bottom: 0,
            right: "10px",
            width: "300px",
            maxHeight: "400px",
            background: "#f0f4ff",
            borderRadius: "10px",
            padding: "10px",
            overflowY: "auto",
            boxShadow: "0 5px 15px rgba(0,0,0,0.2)",
            zIndex: 1000,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <h4>Chat with {selectedChatUser.name}</h4>
          <div style={{ flex: 1, overflowY: "auto", padding: "5px" }}>
            {chatMessages.map((m, i) => (
              <p key={i}>
                <b>{m.senderId === currentUserId ? "You" : m.sender?.name || "Unknown"}:</b>{" "}
                {m.message}
              </p>
            ))}
            {typingUsers[selectedChatUser._id] && (
              <p style={{ fontStyle: "italic", color: "#555" }}>Typing...</p>
            )}
            <div ref={chatEndRef}></div>
          </div>

          <div style={{ display: "flex", gap: "5px", marginTop: "5px" }}>
            <input
              style={{ flex: 1, padding: "8px", borderRadius: "5px", border: "1px solid #ccc" }}
              value={newMessage}
              onChange={handleTyping}
              placeholder="Type a message..."
            />
            <button
              style={{
                padding: "8px 12px",
                backgroundColor: "#4a90e2",
                color: "white",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
              }}
              onClick={sendMessage}
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* 🚪 Logout */}
      <button
        style={{
          backgroundColor: logoutHovered ? "#000" : "#333",
          color: "white",
          padding: "12px 30px",
          border: "none",
          borderRadius: "50px",
          cursor: "pointer",
          fontWeight: "700",
          fontSize: "16px",
          marginTop: "20px",
        }}
        onClick={handleLogout}
        onMouseEnter={() => setLogoutHovered(true)}
        onMouseLeave={() => setLogoutHovered(false)}
      >
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
