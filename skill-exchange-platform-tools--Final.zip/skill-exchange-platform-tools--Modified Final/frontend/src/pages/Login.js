import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setError("");
      const res = await axios.post("http://localhost:5000/api/auth/login", form);
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    }
  };

  const containerStyle = {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundImage:
      "url('https://media.istockphoto.com/id/2200516160/photo/deepfake-concept-facial-tracking-detection-and-recognition-technology-security-system-cyber.jpg?s=612x612&w=0&k=20&c=uXc-_auD7F92F2D18FQk5F_8CjGrvTijez4FOPMb2UI=')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    padding: 20,
  };

  const formStyle = {
    background: "rgba(255, 255, 255, 0.25)",
    backdropFilter: "blur(10px)",
    padding: "40px 30px",
    borderRadius: "12px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.25)",
    width: "100%",
    maxWidth: "400px",
    boxSizing: "border-box",
    textAlign: "center",
    color: "#000",
  };

  const inputStyle = {
    width: "100%",
    padding: "12px 15px",
    margin: "10px 0",
    borderRadius: "8px",
    border: "1.5px solid #ccc",
    fontSize: "16px",
    boxSizing: "border-box",
    outline: "none",
    transition: "border-color 0.3s ease",
  };

  const inputFocusStyle = {
    borderColor: "#000",
    boxShadow: "0 0 8px #000",
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px 0",
    background: "#000", // black button
    border: "none",
    borderRadius: "10px",
    color: "white",
    fontWeight: "600",
    fontSize: "18px",
    cursor: "pointer",
    marginTop: "15px",
    transition: "background 0.3s ease, transform 0.2s ease",
  };

  const buttonHoverStyle = {
    background: "#333", // dark gray hover
    transform: "scale(1.02)",
  };

  const errorStyle = {
    color: "#e74c3c",
    marginTop: "15px",
    fontWeight: "600",
  };

  const [focusedInput, setFocusedInput] = useState(null);

  return (
    <div style={containerStyle}>
      <form
        onSubmit={handleSubmit}
        style={formStyle}
        noValidate
        autoComplete="off"
      >
        <h2 style={{ marginBottom: 20, color: "#000" }}>Login</h2>

        <input
          name="email"
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          onFocus={() => setFocusedInput("email")}
          onBlur={() => setFocusedInput(null)}
          required
          style={{
            ...inputStyle,
            ...(focusedInput === "email" ? inputFocusStyle : {}),
          }}
        />

        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          onFocus={() => setFocusedInput("password")}
          onBlur={() => setFocusedInput(null)}
          required
          style={{
            ...inputStyle,
            ...(focusedInput === "password" ? inputFocusStyle : {}),
          }}
        />

        <button
          type="submit"
          style={buttonStyle}
          onMouseEnter={(e) =>
            Object.assign(e.currentTarget.style, buttonHoverStyle)
          }
          onMouseLeave={(e) =>
            Object.assign(e.currentTarget.style, buttonStyle)
          }
        >
          Login
        </button>

        {error && <p style={errorStyle}>{error}</p>}
      </form>
    </div>
  );
}
