import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import fs from "fs";
import path from "path";
import User from "../models/User.js";

const router = express.Router();

// --------------------------------------------------
// 📁 MULTER CONFIGURATION
// --------------------------------------------------
const uploadDir = path.resolve("uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log("📂 Created uploads directory at:", uploadDir);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/\s+/g, "_");
    cb(null, `${Date.now()}-${safeName}`);
  },
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (!file) return cb(null, false);
    if (file.mimetype === "application/pdf") cb(null, true);
    else cb(null, false);
  },
});

// --------------------------------------------------
// 🧾 USER REGISTRATION ROUTE
// --------------------------------------------------
router.post(
  "/register",
  upload.fields([
    { name: "resume", maxCount: 1 },
    { name: "certification", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      console.log("📩 Registration request received");
      console.log("Received body:", req.body);
      console.log("Received files:", req.files);

      const { name, email, password, skillsOffered, skillsWanted } = req.body;

      if (!name || !email || !password) {
        return res
          .status(400)
          .json({ message: "Name, email, and password are required" });
      }

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(409).json({ message: "Email already registered" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      const resumePath = req.files?.resume
        ? `uploads/${req.files.resume[0].filename}`
        : null;
      const certificationPath = req.files?.certification
        ? `uploads/${req.files.certification[0].filename}`
        : null;

      const newUser = new User({
        name,
        email,
        password: hashedPassword,
        skillsOffered: skillsOffered ? skillsOffered.split(",") : [],
        skillsWanted: skillsWanted ? skillsWanted.split(",") : [],
        resume: resumePath,
        certification: certificationPath,
      });

      await newUser.save();
      console.log("✅ User registered successfully:", email);
      return res.status(201).json({ message: "Registration successful" });
    } catch (error) {
      console.error("❌ Registration error:", error);
      return res.status(500).json({ message: error.message || "Server error" });
    }
  }
);

// --------------------------------------------------
// 🔐 USER LOGIN ROUTE
// --------------------------------------------------
router.post("/login", async (req, res) => {
  try {
    console.log("🔐 Login attempt received");
    const { email, password } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const token = jwt.sign(
      { id: user._id },
      process.env.JWT_SECRET || "default_secret",
      { expiresIn: "7d" }
    );

    console.log("✅ Login successful for:", email);

    return res.json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        resume: user.resume,
        certification: user.certification,
      },
    });
  } catch (error) {
    console.error("❌ Login error:", error);
    return res.status(500).json({ message: error.message || "Server error" });
  }
});

// --------------------------------------------------
// 🧩 VERIFY TOKEN MIDDLEWARE
// --------------------------------------------------
const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader)
    return res.status(401).json({ message: "No token provided" });

  const token = authHeader.split(" ")[1];
  jwt.verify(token, process.env.JWT_SECRET || "default_secret", (err, decoded) => {
    if (err)
      return res.status(403).json({ message: "Invalid or expired token" });
    req.userId = decoded.id;
    next();
  });
};

// --------------------------------------------------
// 👤 GET CURRENT USER INFO
// --------------------------------------------------
router.get("/me", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select("-password");
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (error) {
    console.error("❌ Error fetching current user:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// --------------------------------------------------
// 👥 GET TOTAL USERS COUNT
// --------------------------------------------------
router.get("/count", verifyToken, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    res.json({ totalUsers });
  } catch (error) {
    console.error("❌ Error fetching total users:", error);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
