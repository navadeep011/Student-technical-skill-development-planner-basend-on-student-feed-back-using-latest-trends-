import express from "express";
import User from "../models/User.js";
import jwt from "jsonwebtoken";

const router = express.Router();

// Middleware to verify token
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(403).json({ error: "Unauthorized" });

  const token = authHeader.split(" ")[1];
  if (!token) return res.status(403).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

// Route to fetch all matches for logged-in user
router.get("/", authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    const matches = await User.find({
      skillsOffered: { $in: user.skillsWanted },
      skillsWanted: { $in: user.skillsOffered },
      _id: { $ne: user._id }
    });

    const matchesWithCounts = await Promise.all(
      matches.map(async (match) => {
        const totalMatches = await User.countDocuments({
          skillsOffered: { $in: match.skillsWanted },
          skillsWanted: { $in: match.skillsOffered },
          _id: { $ne: match._id }
        });

        return {
          ...match.toObject(),
          totalMatches,
        };
      })
    );

    res.json(matchesWithCounts);
  } catch (err) {
    console.error("Error fetching matches:", err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ NEW ROUTE: fetch matched users for a specific user
router.get("/:userId", authenticate, async (req, res) => {
  const { userId } = req.params;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    const matchedUsers = await User.find({
      skillsOffered: { $in: user.skillsWanted },
      skillsWanted: { $in: user.skillsOffered },
      _id: { $ne: user._id }
    });

    res.json(matchedUsers); // frontend will receive the list
  } catch (err) {
    console.error("Error fetching matched users:", err);
    res.status(500).json({ error: "Failed to fetch the matches" });
  }
});

export default router;
