import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import fs from "fs";
import User from "../models/User.js";

const router = express.Router();

// Create uploads folder if missing
const uploadDir = "uploads/";
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// ✅ Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${file.fieldname}${ext}`);
  },
});

// ✅ Allow only PDFs
const fileFilter = (req, file, cb) => {
  if (file.mimetype === "application/pdf") cb(null, true);
  else cb(new Error("Only PDF files are allowed"), false);
};

// ✅ Upload middleware (both resume & certification)
const upload = multer({
  storage,
  fileFilter,
}).fields([
  { name: "resume", maxCount: 1 },
  { name: "certification", maxCount: 1 },
]);

// ✅ Register route
router.post("/register", (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      console.error("❌ Multer error:", err);
      return res.status(400).json({ message: err.message });
    }

    try {
      const { name, email, password, skillsOffered, skillsWanted } = req.body;

      // Validation
      if (!name || !email || !password)
        return res.status(400).json({ message: "All fields are required" });

      const existing = await User.findOne({ email });
      if (existing)
        return res.status(400).json({ message: "Email already registered" });

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Handle uploaded files
      const resumePath = req.files?.resume?.[0]?.path || null;
      const certPath = req.files?.certification?.[0]?.path || null;

      // Create new user
      const newUser = new User({
        name,
        email,
        password: hashedPassword,
        skillsOffered: skillsOffered
          ? skillsOffered.split(",").map((s) => s.trim())
          : [],
        skillsWanted: skillsWanted
          ? skillsWanted.split(",").map((s) => s.trim())
          : [],
        resume: resumePath,
        certification: certPath,
      });

      await newUser.save();

      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      console.error("❌ Registration error:", error);
      res.status(500).json({ message: "Server error during registration" });
    }
  });
});

// ✅ Login route
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user)
      return res.status(400).json({ message: "Invalid email or password" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid email or password" });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.json({
      message: "Login successful",
      token,
      user: { id: user._id, name: user.name, email: user.email },
    });
  } catch (error) {
    console.error("❌ Login error:", error);
    res.status(500).json({ message: "Server error during login" });
  }
});

export default router;
