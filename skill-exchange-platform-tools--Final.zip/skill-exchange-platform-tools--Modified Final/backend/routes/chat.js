// routes/chat.js
import express from "express";
import jwt from "jsonwebtoken";
import Chat from "../models/chat.js";

const router = express.Router();

const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(403).json({ error: "Unauthorized" });

  const token = authHeader.split(" ")[1];
  if (!token) return res.status(403).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

// Fetch chat history between logged-in user and otherUserId
router.get("/:otherUserId", authenticate, async (req, res) => {
  const { otherUserId } = req.params;
  try {
    const chat = await Chat.findOne({
      participants: { $all: [req.userId, otherUserId] },
    }).populate("messages.sender", "name");

    if (!chat) return res.json([]);

    // sort by timestamp
    const sorted = chat.messages
      .map((m) => ({
        _id: m._id,
        sender: m.sender ? { _id: m.sender._id, name: m.sender.name } : { _id: m.sender, name: "Unknown" },
        message: m.message,
        timestamp: m.timestamp,
      }))
      .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    res.json(sorted);
  } catch (err) {
    console.error("GET /chat error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Save a message via REST and emit real-time using io (if available)
router.post("/:otherUserId", authenticate, async (req, res) => {
  const { otherUserId } = req.params;
  const { message } = req.body;

  if (!message || !message.trim()) {
    return res.status(400).json({ error: "Message cannot be empty" });
  }

  try {
    let chat = await Chat.findOne({
      participants: { $all: [req.userId, otherUserId] },
    });

    if (!chat) {
      chat = new Chat({
        participants: [req.userId, otherUserId],
        messages: [],
      });
    }

    const newMsg = { sender: req.userId, message, timestamp: new Date() };
    chat.messages.push(newMsg);
    await chat.save();

    // Populate the last message sender name
    await chat.populate("messages.sender", "name");
    const savedMessage = chat.messages[chat.messages.length - 1];

    // Emit via socket.io if available
    const io = req.app.get("io");
    if (io) {
      // emit to both participants (if online they'll receive)
      io.to(req.userId).emit("receiveMessage", savedMessage);
      io.to(otherUserId).emit("receiveMessage", savedMessage);

      // if you use a map of userId->socketId (server.js maintains), it's also okay
    }

    res.json(savedMessage);
  } catch (err) {
    console.error("POST /chat error:", err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
