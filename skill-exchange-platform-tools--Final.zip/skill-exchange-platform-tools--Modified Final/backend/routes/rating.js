import express from "express";
import User from "../models/User.js";
import jwt from "jsonwebtoken";

const router = express.Router();

const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(403).json({ error: "Unauthorized" });

  const token = authHeader.split(" ")[1];
  if (!token) return res.status(403).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
};

router.post("/submit", authenticate, async (req, res) => {
  const { ratedUserId, comment, rating } = req.body;
  try {
    const ratedUser = await User.findById(ratedUserId);
    if (!ratedUser) return res.status(404).json({ error: "Rated user not found" });

    ratedUser.feedbacks.push({ userId: req.userId, comment, rating });
    ratedUser.rating = ratedUser.feedbacks.reduce((acc, cur) => acc + cur.rating, 0) / ratedUser.feedbacks.length;

    await ratedUser.save();
    res.json({ message: "Feedback submitted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
