import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import fs from "fs";
import path from "path";
import { createServer } from "http";
import { Server } from "socket.io";

import authRoutes from "./routes/auth.js";
import matchRoutes from "./routes/match.js";
import ratingRoutes from "./routes/rating.js";
import userRoutes from "./routes/user.js";
import chatRoutes from "./routes/chat.js";

import Chat from "./models/chat.js";
import User from "./models/User.js";

dotenv.config();

const app = express();
const httpServer = createServer(app);

// --------------------------------------------------
// ⚙️ SOCKET.IO SETUP
// --------------------------------------------------
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || "*", // 👈 safer for prod
    methods: ["GET", "POST"],
  },
});

// --------------------------------------------------
// 🧠 GLOBAL MIDDLEWARE
// --------------------------------------------------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set("io", io);

// --------------------------------------------------
// 📂 SERVE UPLOADS DIRECTORY
// --------------------------------------------------
const uploadDir = path.resolve("uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
app.use("/uploads", express.static(uploadDir));

// --------------------------------------------------
// 🚏 ROUTES
// --------------------------------------------------
app.use("/api/auth", authRoutes);
app.use("/api/match", matchRoutes);
app.use("/api/rating", ratingRoutes);
app.use("/api/users", userRoutes);
app.use("/api/chat", chatRoutes);

// --------------------------------------------------
// 💬 SOCKET.IO EVENTS
// --------------------------------------------------
const onlineUsers = {};

io.on("connection", (socket) => {
  console.log(`⚡ Socket connected: ${socket.id}`);

  // When a user joins (track userId)
  socket.on("join", (userId) => {
    onlineUsers[userId] = socket.id;
    socket.userId = userId;
    console.log(`👤 User ${userId} joined (socket: ${socket.id})`);
  });

  // Handle chat messages
  socket.on("sendMessage", async ({ otherUserId, message }) => {
    try {
      const senderId = socket.userId;
      if (!senderId) return;

      let chat = await Chat.findOne({
        participants: { $all: [senderId, otherUserId] },
      });

      if (!chat) {
        chat = new Chat({
          participants: [senderId, otherUserId],
          messages: [],
        });
      }

      const newMsg = { sender: senderId, message, timestamp: new Date() };
      chat.messages.push(newMsg);
      await chat.save();

      const populated = await chat.populate({
        path: "messages.sender",
        select: "name",
      });

      const savedMessage = populated.messages.at(-1);

      // Emit to sender and receiver
      socket.emit("receiveMessage", savedMessage);
      const receiverSocketId = onlineUsers[otherUserId];
      if (receiverSocketId) io.to(receiverSocketId).emit("receiveMessage", savedMessage);
    } catch (err) {
      console.error("❌ sendMessage error:", err);
    }
  });

  // Handle disconnection
  socket.on("disconnect", () => {
    console.log(`🔌 Socket disconnected: ${socket.id}`);
    for (const uid in onlineUsers) {
      if (onlineUsers[uid] === socket.id) {
        delete onlineUsers[uid];
        console.log(`👋 User ${uid} went offline`);
        break;
      }
    }
  });
});

// --------------------------------------------------
// 🛢️ MONGODB CONNECTION + SERVER START
// --------------------------------------------------
mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/skill_exchange", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    console.log("✅ MongoDB connected");

    const totalUsers = await User.countDocuments();
    console.log(`👥 Total users in DB: ${totalUsers}`);

    const PORT = process.env.PORT || 5000;
    httpServer.listen(PORT, () =>
      console.log(`🚀 Server running on http://localhost:${PORT}`)
    );
  })
  .catch((err) => console.error("❌ MongoDB connection error:", err));
